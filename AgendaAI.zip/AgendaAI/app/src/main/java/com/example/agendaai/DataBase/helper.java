package com.example.agendaai.DataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class helper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "usuarios.db";
    private static final int DATABASE_VERSION = 2;

    // Nome da tabela e colunas
    private static final String TABLE_NAME = "Usuarios";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_DATA_NASCIMENTO = "data_nascimento";
    private static final String COLUMN_TELEFONE = "telefone";
    private static final String COLUMN_SENHA = "senha";

    public helper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_EMAIL + " TEXT PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_DATA_NASCIMENTO + " TEXT, " +
                COLUMN_TELEFONE + " TEXT, " +
                COLUMN_SENHA + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Método para inserir um novo usuário
    public boolean inserirUsuario(String email, String dataNascimento, String telefone, String senha) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_DATA_NASCIMENTO, dataNascimento);
        values.put(COLUMN_TELEFONE, telefone);
        values.put(COLUMN_SENHA, senha);

        long result = db.insert(TABLE_NAME, null, values);
        db.close();
        return result != -1;
    }

}

