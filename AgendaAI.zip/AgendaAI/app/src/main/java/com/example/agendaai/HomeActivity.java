package com.example.agendaai;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

// HomeActivity.java
public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homeactivity);

        // Configurações e lógica para a tela principal
    }
}

