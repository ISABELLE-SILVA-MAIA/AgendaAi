package com.example.agendaai;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText emailEditText, dataNascimentoEditText, telefoneEditText, senhaEditText;
    private Button cadastrarButton;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar o DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Referência dos campos
        emailEditText = findViewById(R.id.emailEditText);
        dataNascimentoEditText = findViewById(R.id.dataNascimentoEditText);
        telefoneEditText = findViewById(R.id.telefoneEditText);
        senhaEditText = findViewById(R.id.senhaEditText);
        cadastrarButton = findViewById(R.id.cadastrarButton);

        // Listener para o botão de cadastro
        cadastrarButton.setOnClickListener(view -> cadastrarUsuario());
    }

    private void cadastrarUsuario() {
        String email = emailEditText.getText().toString();
        String dataNascimento = dataNascimentoEditText.getText().toString();
        String telefone = telefoneEditText.getText().toString();
        String senha = senhaEditText.getText().toString();

        // Verificar se todos os campos estão preenchidos
        if (email.isEmpty() || dataNascimento.isEmpty() || telefone.isEmpty() || senha.isEmpty()) {
            Toast.makeText(this, "Todos os campos são obrigatórios", Toast.LENGTH_SHORT).show();
            return;
        }

        // Inserir usuário no banco de dados
        boolean isInserted = databaseHelper.inserirUsuario(email, dataNascimento, telefone, senha);
        if (isInserted) {
            Toast.makeText(this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show();
            // Limpar os campos ou redirecionar o usuário para outra tela
        } else {
            Toast.makeText(this, "Erro ao realizar o cadastro", Toast.LENGTH_SHORT).show();
        }

        // Após salvar os dados no banco de dados (na CadastroActivity)
        // Após salvar os dados no banco de dados (na CadastroActivity)
            Toast.makeText(this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish(); // Fecha a tela de cadastro
    }

    private class DatabaseHelper {
        public DatabaseHelper(MainActivity mainActivity) {
        }

        public boolean inserirUsuario(String email, String dataNascimento, String telefone, String senha) {
            return false;
        }
    }

}
