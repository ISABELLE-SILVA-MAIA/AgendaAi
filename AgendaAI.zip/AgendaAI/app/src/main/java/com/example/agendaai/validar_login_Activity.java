package com.example.agendaai;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
// DatabaseHelper.java

public class TABLE_USUARIOS {
    private SQLiteDatabase validar_login_Activity;

    public SQLiteDatabase validar_login_Activity(String email, String senha) {
            SQLiteDatabase db = this.validar_login_Activity;
            String TABLE_USUARIOS = new String();
            Cursor cursor = db.query(TABLE_USUARIOS,
                    new String[]{email, senha},
                    email + "=? AND " + senha + "=?",
                    new String[]{email, senha},
                    null, null, null);

            boolean isValid = cursor.getCount() > 0;  // Retorna verdadeiro se o usuário existir no banco
            cursor.close();
        return db;
    }
}
