package com.example.agendaai;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// LoginActivity.java
public class LoginActivity extends AppCompatActivity {

    private View emailEditText;
    private View senhaEditText;
    private View loginButton;
    private View registroTextView;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_login_main);

        // Inicializar as views
        emailEditText = findViewById(R.id.emailEditText);
        senhaEditText = findViewById(R.id.senhaEditText);
        loginButton = findViewById(R.id.loginButton);
        registroTextView = findViewById(R.id.registroTextView);

        // Instanciar o DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Configurar o botão de login
        loginButton.setOnClickListener(view -> realizarLogin());

        // Configurar o link para a tela de cadastro
        registroTextView.setOnClickListener(view -> {
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }

    private void realizarLogin() {
        String email = String.valueOf(emailEditText.getLeft());
        String senha = String.valueOf(senhaEditText.getLeft());

        // Validação dos campos
        if (email.isEmpty() || senha.isEmpty()) {
            Toast.makeText(this, "Todos os campos são obrigatórios", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validar login no banco de dados
        if (databaseHelper.validarLogin(email, senha)) {
            Toast.makeText(this, "Login bem-sucedido!", Toast.LENGTH_SHORT).show();
            // Navegar para a próxima tela
            Intent intent = new Intent(LoginActivity.this, HomeActivity.class); // Tela principal
            startActivity(intent);
            finish(); // Finaliza a LoginActivity para que o usuário não retorne ao login pressionando o botão voltar
        } else {
            Toast.makeText(this, "E-mail ou senha incorretos", Toast.LENGTH_SHORT).show();
        }
    }

    private class EditText {
    }

    private class Button {
        public void setOnClickListener(Object o) {

        }
    }

    private class TextView {
        public void setOnClickListener(Object o) {

        }
    }

    private class DatabaseHelper {
        public DatabaseHelper(LoginActivity loginActivity) {

        }

        public boolean validarLogin(String email, String senha) {
            return false;
        }
    }

    private class HomeActivity {
    }
}

