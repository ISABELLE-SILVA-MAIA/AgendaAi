package com.example.estudio_w.model

class Servico (
    val img: Int? = null,
    val nome: String? = null
)