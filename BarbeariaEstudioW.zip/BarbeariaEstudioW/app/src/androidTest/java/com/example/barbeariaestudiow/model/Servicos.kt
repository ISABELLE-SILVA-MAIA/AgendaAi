package com.example.barbeariaestudiow.model

data class Servicos {
    val img: Int? null,
    
    val img: Int? null,
}